import './PieChart.css'
import {useEffect, useState, useRef} from 'react';

function PieChart(props) {

    const [toolTipProps, setToolTipProps] = useState({text: "", value: 0, x: 0, y: 0, visible: false});
    const containerRef = useRef(null);
    const svgRef = useRef(null);
    const initDoneRef = useRef(false);

    const viewBox = {width: 100, height: 100};

    const title = {
        text: "World population",
        x: 0, y: 0,
        width: 100,
        height: 10,
        baseline: 5};   

    let squareVerticesBuffer;
    let shaderProgram;
    let vertexPositionAttribute;
    let transform;
    let color;
    let count;
    let origin;
    let radius;

    let gl = null;
    let canvas = null;
    let svg = null;
    let circleCount = 128;
    let sliceAngles = dataSliceInfo(props.data.data.map(d => d.population));

    // Handles toolTip logic
    useEffect(() => {
        const handleWindowMouseMove = event => {
            if (svgRef.current) {
                // Gets SVG coordinates of mouse pointer
                const pt = svgRef.current.createSVGPoint();
                pt.x = event.clientX;
                pt.y = event.clientY;
                const svgP = pt.matrixTransform(svgRef.current.getScreenCTM().inverse());
                const dx = svgP.x - 50;
                const dy = svgP.y - 55;
                // Converts cartesian mouse coordinates to polar coordinates
                const newRadius = Math.sqrt(dx * dx + dy * dy);
                const newTheta = Math.atan2(dy, dx);
                // If mouse is in circle, render toolTip
                if (newRadius <= 40.5)   {
                    // Get the current angle of the mouse pointer
                    // Converts it to a value from [0 , 1] for easier comparison
                    const currAngle = ((newTheta + Math.PI) / (2 * Math.PI) + 0.5) % 1;
                    // Finds which slice the mouse is in
                    for (let i = 0; i < sliceAngles.length; i++)    {
                        if (sliceAngles[i] / 128 > currAngle) {
                            console.log(i)
                            let sliceData = props.data.data;
                            // Once found, loads toolTip with corresponding data
                            setToolTipProps({
                                text: "Year: " + sliceData[i].year, 
                                value: "Population: " + sliceData[i].population,
                                x: event.clientX,  
                                y: event.clientY, 
                                visible: true});
                            break;
                        }
                    }

                }   else    { // Otherwise, don't render toolTip
                    setToolTipProps({text: "", value: 0, x: 0, y: 0, visible: false});
                }
            }
        };
        
        window.addEventListener('mousemove', handleWindowMouseMove);
        return () => {
            window.removeEventListener('mousemove', handleWindowMouseMove);
        };
    }, []);  

    // Manages window event listeners and ensures they are only created
    // once init() is run.
    useEffect(() => {
        if (initDoneRef.current) return;  
        initDoneRef.current = true;
        
        const handleLoad = () => {
            init();
        };
        const handleResize = () => {
            display();
        };
        if (document.readyState === 'complete') {
            init();
        } else {
            window.addEventListener('load', handleLoad);
        }
        window.addEventListener('resize', handleResize);
        
        return () => {
            window.removeEventListener('load', handleLoad);
            window.removeEventListener('resize', handleResize);
        };
    }, []);

    function init() {
        canvas = d3 // Appends a canvas element to the body.
            .select("#pieChart")
            .append("canvas")
        
        // initSvg code is now here
        svg = d3
            .select("#pieChart")
            .append("svg")
            .attr("viewBox", "0 0 " + viewBox.width + " " + viewBox.height)
            .attr("preserveAspectRatio", "xMidYMid");
        svg
            .append("g")
            .attr("id", "title")
            .append("text")
            .attr("x", title.x + title.width / 2)
            .attr("y", title.y + title.height - title.baseline)
            .text(title.text);
    
        // Initiates ref hook to use in mouseListener later.
        svgRef.current = svg.node();

        try {
            gl = canvas.node().getContext("webgl2") || canvas.node().getContext("webgl");
        }
        catch (e) {
            console.log('WebGL context not available!')
        }
        if (gl) {
            gl.clearColor(1.0, 1.0, 1.0, 1.0);
            initShaders();
            initBuffers();
            display();
        }
    }

    function resize() {
        const container = document.getElementById('pieChart');
        if (container) {
            // Ensures the viewport remains a square
            const dim = container.offsetWidth;
            canvas.node().width = dim;
            canvas.node().height = dim;
            if (gl) {
                gl.viewport(0, 0, dim, dim);
            }
        }
    }

    // Untouched from skeleton files
    function getShader(gl, id) {
        let shaderScript = document.getElementById(id);
        if (!shaderScript) {
            return null;
        }
        let theSource = "";
        let currentChild = shaderScript.firstChild;
        while(currentChild) {
            if (currentChild.nodeType == 3) {
                theSource += currentChild.textContent;
            }
            currentChild = currentChild.nextSibling;
        }
        let shader;
        if (shaderScript.type == "x-shader/x-fragment") {
            shader = gl.createShader(gl.FRAGMENT_SHADER);
        } else if (shaderScript.type == "x-shader/x-vertex") {
            shader = gl.createShader(gl.VERTEX_SHADER);
        } else {
            return null;
        }
        gl.shaderSource(shader, theSource);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            alert("An error occurred compiling the shaders: " + gl.getShaderInfoLog(shader));
            return null;
        }
        return shader;
    }

    // untouched from skeleton files
    function initShaders() {
        let fragmentShader = getShader(gl, "fragment-shader");
        let vertexShader = getShader(gl, "vertex-shader");
        shaderProgram = gl.createProgram();
        gl.attachShader(shaderProgram, vertexShader);
        gl.attachShader(shaderProgram, fragmentShader);
        gl.linkProgram(shaderProgram);
        if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
            alert("Unable to initialize the shader program.");
        }
        gl.useProgram(shaderProgram);
    }

    function initBuffers() {
        squareVerticesBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, squareVerticesBuffer);
        let circleData = new Array(circleCount + 1);
        for (let i = 0; i < circleCount; i++) {
            circleData[i] = i;
        }
        var vertices = new Float32Array(circleData);
        gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
        gl.vertexAttribPointer(vertexPositionAttribute, 1, gl.FLOAT, false, 0, 0);
    }

    // Creates an array that which slice a data point belongs to
    function dataSliceInfo(dataArr)    { 
        let sum = 0.0;
        for (let i = 0; i < dataArr.length; i++)   {
            sum += dataArr[i];
        }
        let sliceCoords = new Array(dataArr.length);
        let cumSum = 0;
        for (let i = 0; i < dataArr.length; i++)   {
            cumSum += dataArr[i]
            sliceCoords[i] = Math.floor((cumSum / sum) * circleCount);
        }
        return sliceCoords;
    }

    // This draws a singular slice from the vertex at the starting index to the vert at the last index
    function drawSlice(startIndex, lastIndex)    {
        // Creates an array with all the vertices in the current slice
        let sliceVertices = new Array(lastIndex - startIndex + 1);
        sliceVertices[0] = 129; // 129 is the "origin"
        for (let i = startIndex; i < lastIndex + 1; i++)    {
            sliceVertices[i - startIndex + 1] = i;
        }
        var vertices = new Float32Array(sliceVertices);
        gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
        gl.vertexAttribPointer(vertexPositionAttribute, 1, gl.FLOAT, false, 0, 0);
        gl.drawArrays(gl.TRIANGLE_FAN, 0, sliceVertices.length);
    }

    // Simple function gets a color from some fraction [0, 1]
    function getColorFromGradient(num) {
        return {
            r: Math.abs(num),
            g: Math.abs(num - 0.33),
            b: Math.abs(num - 0.66)
        };
    }

    function drawCircle()   {
        let sliceColor;
        // draws the first slice
        sliceColor = getColorFromGradient(0 / sliceAngles.length);
        gl.uniform4f(color, sliceColor.r, sliceColor.g, sliceColor.b, 1.0);
        drawSlice(0, sliceAngles[0]);
        // draws the rest
        for (let i = 1; i < sliceAngles.length; i++)   {
            sliceColor = getColorFromGradient(i / sliceAngles.length);
            gl.uniform4f(color, sliceColor.r, sliceColor.g, sliceColor.b, 1.0);
            drawSlice(sliceAngles[i - 1], sliceAngles[i]);
        }
    }

    function display() {
        resize();
        initBuffers();
        gl.clear(gl.COLOR_BUFFER_BIT);
        vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "vertexPosition");
        gl.enableVertexAttribArray(vertexPositionAttribute);

        transform = gl.getUniformLocation(shaderProgram, "transform");
        color = gl.getUniformLocation(shaderProgram, "color");
        count = gl.getUniformLocation(shaderProgram, "count");
        origin = gl.getUniformLocation(shaderProgram, "origin");
        radius = gl.getUniformLocation(shaderProgram, "radius");

        // Transform webgl coordinates [1, -1] to svg coordinates [100, -100]
        gl.uniformMatrix4fv(transform, false, new Float32Array([
            0.02,  0.00, 0.0, 0.0, // One x-unit in webgl is 0.2 when converted from svg
            0.00,  -0.02, 0.0, 0.0,
            0.00,  0.00, 1.0, 0.0,
            -1.0,  1.00, 0.0, 1.0]));

        // Sets uniform values to draw the circle with 
        gl.uniform4f(color, 0.75,0.75, 0.75, 1.0);
        gl.uniform2f(origin, 50.0, 55.0);
        gl.uniform1f(radius, 40.5);
        gl.uniform1f(count, circleCount);

        // draws red outline
        gl.uniform4f(color, 1.0, 0.0, 0.0, 1.0)
        gl.drawArrays(gl.LINE_LOOP, 0, circleCount);

        // Fills teal circle
        drawCircle();
    }

    return (
        <div id="pieChart" ref={containerRef}>
        {toolTipProps.visible && (
            <div style={{
                position: 'fixed',
                left: `${toolTipProps.x}px`,
                top: `${toolTipProps.y}px`,
                background: 'rgba(127, 127, 127, 1.0)',
                color: 'white',
                padding: '8px 12px',
                borderRadius: '6px',
                transform: 'translate(-50%, -120%)', // Centers and positions above cursor
            }}>
                <div>{toolTipProps.text}</div>
                <div>{toolTipProps.value}</div>
            </div>
        )}
        </div>
    )
}

export default PieChart